package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
	"sync"
	"time"
	"math"
	"io/ioutil"
	"path/filepath"

	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

type Car struct{
	Id     string `json:"id"`
	Credit string `json:"credit"`
	Tag    string `json:"tag"`
}

type QuMessage struct {
	Tag string
	Id string
	Cartg string
}

type TxMessage struct {
	Tag string
	Whoami Car
	CurrentTime time.Time
	Status string
}

type bufferSync struct {
	mu sync.RWMutex
	msgBuffer map[int]TxMessage
}


type hostsNsync struct {
	hosts map[string]net.Conn
	mu sync.RWMutex
}

var hostsNsyn hostsNsync

func HandleNmsg(connection net.Conn, bufferSync *bufferSync, wg *sync.WaitGroup){
	defer wg.Done()
	defer connection.Close()
	for {
		//read
		buf := make([]byte, 1024)
		println("Server: Start to read from the connection: "+connection.RemoteAddr().String())
		n, err := connection.Read(buf)
		if err != nil {
			println("Server: connection to "+connection.RemoteAddr().String()+" interrupted")
			return
		}
		println("Server: The message is that: "+ string(buf[:n]))
		var msg TxMessage
		json.Unmarshal(buf[:n], &msg)

		//operation
		bufferSync.mu.Lock()
		if msg.Whoami.Tag == "n" {
			bufferSync.msgBuffer[len(bufferSync.msgBuffer)] = msg
		}else{
			log.Fatal("received non-normal message from the connection to a normal car:\n")
		}
		bufferSync.mu.Unlock()
	}
}

func HandleAumsg(connection net.Conn, bufferSync *bufferSync, wg *sync.WaitGroup, contract * gateway.Contract){
	defer wg.Done()
	defer connection.Close()
	for {
		//read
		buf := make([]byte, 1024)
		println("Server: Start to read from the connection: "+connection.RemoteAddr().String())
		n, err := connection.Read(buf)
		if err != nil {
			println("Server: connection to "+connection.RemoteAddr().String()+" interrupted")
			return
		}
		println("Server: The message is that: "+ string(buf[:n]))
		var msg TxMessage
		json.Unmarshal(buf[:n], &msg)

		//operation
		println("msg buffer length: "+string(len(bufferSync.msgBuffer)))
		bufferSync.mu.Lock()
		if(msg.Whoami.Tag == "au" && len(bufferSync.msgBuffer) != 0){
			for i := len(bufferSync.msgBuffer) - 1; i >= 0; i-- {
				thisMsg := bufferSync.msgBuffer[i]
				car := thisMsg.Whoami
				if math.Abs(float64(thisMsg.CurrentTime.Unix()-msg.CurrentTime.Unix())) > 60 {
					break
				}

				if thisMsg.Status == msg.Status {

					//transact
					println("Server: " + car.Id + " reports the true road status and we will increase its credit")
					_, err := contract.SubmitTransaction("ChangeCarCreditRsu",car.Id,"1","add")
					if err != nil {
						log.Fatalf("Failed to Submit transaction: %v", err)
					}

					//notice
					result,err := contract.EvaluateTransaction("QueryCar",car.Id)
					json.Unmarshal(result,&car)

					println("Server: "+ car.Id+ "'s current credit is that: "+ car.Credit)
					hostsNsyn.mu.RLock()
					carCon := hostsNsyn.hosts[car.Id]
					hostsNsyn.mu.RUnlock()
					carCon.Write(result)
				} else {

					//transact
					println("Server: " + bufferSync.msgBuffer[i].Whoami.Id + " reports the false road status and we will decrease its credit")
					_, err := contract.SubmitTransaction("ChangeCarCreditRsu",car.Id,"1","minus")
					if err != nil {
						log.Fatalf("Failed to Submit transaction: %v", err)
					}

					//notice
					result,err := contract.EvaluateTransaction("QueryCar",car.Id)
					json.Unmarshal(result,&car)

					println("Server: "+ car.Id+ "'s current credit is that: "+ car.Credit)
					hostsNsyn.mu.RLock()
					carCon := hostsNsyn.hosts[car.Id]
					hostsNsyn.mu.RUnlock()
					carCon.Write(result)
				}
				delete(bufferSync.msgBuffer, i)
				time.Sleep(3)
			}

			//for k, _ := range bufferSync.msgBuffer {
			//	delete(bufferSync.msgBuffer, k)
			//}

		}
		bufferSync.mu.Unlock()
	}
}


func populateWallet(wallet *gateway.Wallet) error {
	log.Println("============ Populating wallet ============")
	credPath := filepath.Join(
		"..",
		"organizations",
		"peerOrganizations",
		"rsu.com",
		"users",
		"Admin@rsu.com",
		"msp",
	)

	certPath := filepath.Join(credPath, "signcerts", "Admin@rsu.com-cert.pem")
	// read the certificate pem
	cert, err := ioutil.ReadFile(filepath.Clean(certPath))
	if err != nil {
		return err
	}

	keyDir := filepath.Join(credPath, "keystore")
	// there's a single file in this dir containing the private key
	files, err := ioutil.ReadDir(keyDir)
	if err != nil {
		return err
	}
	if len(files) != 1 {
		return fmt.Errorf("keystore folder should have contain one file")
	}
	keyPath := filepath.Join(keyDir, files[0].Name())
	key, err := ioutil.ReadFile(filepath.Clean(keyPath))
	if err != nil {
		return err
	}

	identity := gateway.NewX509Identity("RsuMSP", string(cert), string(key))

	return wallet.Put("appUser", identity)
}

func main(){
	//截取自assetTransfer###################BEGIN
	log.Println("============ application-golang starts ============")

	wallet, err := gateway.NewFileSystemWallet("wallet")
	if err != nil {
		log.Fatalf("Failed to create wallet: %v", err)
	}

	if !wallet.Exists("appUser") {
		err = populateWallet(wallet)
		if err != nil {
			log.Fatalf("Failed to populate wallet contents: %v", err)
		}
	}

	ccpPath := filepath.Join(
		".",
		"connection-profile-rsu1.yaml",
	)

	gw, err := gateway.Connect(
		gateway.WithConfig(config.FromFile(filepath.Clean(ccpPath))),
		gateway.WithIdentity(wallet, "appUser"),
	)
	if err != nil {
		log.Fatalf("Failed to connect to gateway: %v", err)
	}
	defer gw.Close()

	network, err := gw.GetNetwork("channel1")
	if err != nil {
		log.Fatalf("Failed to get network: %v", err)
	}

	contract := network.GetContract("exp")
	//截取自assetTransfer###################END


	//业务逻辑################BEGIN

	hostsNsyn.hosts=make(map[string]net.Conn)

	bufSync := bufferSync{
		msgBuffer: make(map[int]TxMessage),
	}
	var wg sync.WaitGroup
	l,_:=net.Listen("tcp","0.0.0.0:7996")
	defer l.Close()
	println("Server: listening... ")
	println("Protocol: "+l.Addr().Network()+" Address:"+l.Addr().String())


	for  {
		conn, err := l.Accept()
		if err != nil {
			log.Fatal(err)
		}
		println("Server: Have accepted a connection request from:  "+ conn.RemoteAddr().String())
		//response to the car's query request
		quMsgBuf := make([]byte,1024)
		quMsgBufLen, _ := conn.Read(quMsgBuf)
		var quMsg QuMessage
		json.Unmarshal(quMsgBuf[:quMsgBufLen],&quMsg)
		if quMsg.Tag!="query"{
			log.Fatal("received a incorrect query message from car: " + quMsg.Id)
		}
		//handle transaction messages
		if quMsg.Cartg == "n"{
			hostsNsyn.mu.Lock()
			hostsNsyn.hosts[quMsg.Id] = conn
			hostsNsyn.mu.Unlock()
			wg.Add(1)
			result,err:=contract.EvaluateTransaction("QueryCar",quMsg.Id)
			if err != nil{
				println("failed query car "+quMsg.Id)
				wg.Done()
				conn.Close()
				continue
			}
			conn.Write(result)
			go HandleNmsg(conn,&bufSync,&wg)
		}else if quMsg.Cartg == "au"{
			wg.Add(1)
			result,err:=contract.EvaluateTransaction("QueryCar",quMsg.Id)
			if err != nil{
				log.Fatal("failed query car "+quMsg.Id)
			}
			conn.Write(result)
			go HandleAumsg(conn,&bufSync,&wg,contract)
		}

	}
	wg.Wait()
	//业务逻辑####################END
}

